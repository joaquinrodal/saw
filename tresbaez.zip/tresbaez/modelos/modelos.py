#----------------------------------------------------------------------------
# MODELOS DE DATOS SQLMODEL
#----------------------------------------------------------------------------
# Features = Caracteristicas.

from typing import Optional,List , Dict , TypeVar , Generic
from sqlmodel import Field, SQLModel, create_engine ,Session ,select ,Relationship
from pydantic import root_validator
from pydantic import BaseModel
from sqlalchemy.orm import column_property, declared_attr
from slugify import slugify
import json
from sqlalchemy import Integer, String, Text, Column , Boolean , Time, DateTime
from sqlalchemy import ARRAY




from sqlmodel import JSON, Column
from pydantic.fields import PrivateAttr
from pydantic_computed import Computed, computed




url = f"mariadb+mariadbconnector://joaquin:adriana03@localhost/tresbaez"
engine = create_engine(url, echo=True ,future=True, pool_recycle=1200)
db = Session(engine)




class Usuario(SQLModel,table=True):

    usuario:str 
    clave:str 
    perfil:Optional[str] = Field(sa_column = Column("perfil",Text(600)),default='')

    eliminado:Optional[bool]  = Field(sa_column = Column("eliminado",Boolean),default=False)
    id: Optional[int] = Field(default=None, primary_key=True, nullable=False)
    notas: List["Nota"] = Relationship(back_populates="usuario")
    tokens: List["Token"] = Relationship(back_populates="usuario")

    @property 
    def datos(self):
        notas = db.query(Nota).filter(Nota.usuario_id == self.id).all()
        print('NOTAS;-->',dir(notas))
        #return [{'a':1},{'b':6}]
        return notas

class UsuarioSal(Usuario):
    prop_difference: List[Dict] = Field(alias="notas",sa_column=Column(JSON))
    #prop_difference2: str = Field(alias="datos")
    prop_difference3: List[Dict] = Field(alias="datos",sa_column=Column(JSON))



class Nota(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True, nullable=False)
    descripcion:str
    usuario_id: Optional[int] = Field(default=None, foreign_key="usuario.id")
    usuario: Optional[Usuario] = Relationship(back_populates="notas")

class NotaSal(Nota):
    pass

class Token(SQLModel, table=True):

    id: Optional[int] = Field(default=None, primary_key=True, nullable=False)
    sw_token:Optional[str] = Field(sa_column = Column("sw_token",Text(600)),default='')
    usuario_id: Optional[int] = Field(default=None, foreign_key="usuario.id")
    usuario: Optional[Usuario] = Relationship(back_populates="tokens")

class Cliente(SQLModel, table=True):

    id: Optional[int] = Field(default=None, primary_key=True, nullable=False)
    nombre:Optional[str]  = Field(sa_column = Column("nombre",Text(1000)),default='')
    nif_cif:Optional[str]  = Field(sa_column = Column("nif_cif",Text(100)),default='')
    web:Optional[str]  = Field(sa_column = Column("web",Text(100)),default='')
    email:Optional[str]  = Field(sa_column = Column("email",Text(100)),default='')
    tf1:Optional[str]  = Field(sa_column = Column("tf1",Text(20)),default='')
    tf2:Optional[str]  = Field(sa_column = Column("tf2",Text(20)),default='')
    fax:Optional[str]  = Field(sa_column = Column("fax",Text(20)),default='')
    eliminado:Optional[bool]  = Field(sa_column = Column("eliminado",Boolean),default=False)

    direcciones: List["Direccion"] = Relationship(back_populates="cliente", sa_relationship_kwargs={"lazy": "selectin","cascade":"all, delete"})
    contactos: List["Contacto"] = Relationship(back_populates="cliente",sa_relationship_kwargs={"lazy": "selectin","cascade":"all, delete"})

class Direccion(SQLModel, table=True):

    id: Optional[int] = Field(default=None, primary_key=True, nullable=False)
    nombre:Optional[str]  = Field(sa_column = Column("nombre",Text(1000)),default='')
    cp:Optional[str]  = Field(sa_column = Column("cp",Text(1000)),default='')
    municipio:Optional[str]  = Field(sa_column = Column("municipio",Text(1000)),default='')
    provincia:Optional[str]  = Field(sa_column = Column("provincia",Text(1000)),default='')
    observaciones:Optional[str]  = Field(sa_column = Column("observaciones",Text(1000)),default='')
    eliminado:Optional[bool]  = Field(sa_column = Column("eliminado",Boolean),default=False)

    cliente_id : Optional[int] = Field(default=None, foreign_key="cliente.id")
    cliente : Optional[Cliente] = Relationship(back_populates="direcciones",sa_relationship_kwargs={"lazy": "selectin"})

class Contacto(SQLModel, table=True):

    id: Optional[int] = Field(default=None, primary_key=True, nullable=False)
    nombre:Optional[str]  = Field(sa_column = Column("nombre",Text(1000)),default='')
    movil:Optional[str]  = Field(sa_column = Column("movil",Text(100)),default='')
    email:Optional[str]  = Field(sa_column = Column("email",Text(100)),default='')
    cargo:Optional[str]  = Field(sa_column = Column("cargo",Text(100)),default='')
    observaciones:Optional[str]  = Field(sa_column = Column("observaciones",Text(1000)),default='')

    eliminado:Optional[bool]  = Field(sa_column = Column("eliminado",Boolean),default=False)

    cliente_id : Optional[int] = Field(default=None, foreign_key="cliente.id")
    cliente : Optional[Cliente] = Relationship(back_populates="contactos",sa_relationship_kwargs={"lazy": "selectin"}) 











