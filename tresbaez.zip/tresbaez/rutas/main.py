#--------------------------------------------------------------
# API BASE DATOS 
#--------------------------------------------------------------
import os
import httpx
from os import getcwd
from servidor import app , plantilla
from modelos.modelos import *
from conexion import get_session
from fastapi import Request ,Response , WebSocket, WebSocketDisconnect , Cookie ,Header 
from fastapi import File, UploadFile,Form, Depends,  HTTPException, status
from fastapi.responses import RedirectResponse, HTMLResponse ,FileResponse,JSONResponse
from sqlmodel import Session  
from fastapi import Depends
import pandas as pd
from pydantic import BaseModel
from typing import Annotated

from sqlmodel import SQLModel, create_engine
from sqlmodel.ext.asyncio.session import AsyncSession, AsyncEngine

from sqlmodel import  or_, select ,col 
from sqlmodel import Field, Session, SQLModel, create_engine, select
from pywebpush import webpush, WebPushException
from sse_starlette.sse import EventSourceResponse
import asyncio
import threading
import time

from fastapi import Depends
import requests
from jwt import encode ,decode
import json

from fastapi_pagination import Page, add_pagination, paginate ,LimitOffsetPage


from sqlalchemy.orm import selectinload

#-----------------------------------------------------------
# REDIS ,instalacion,  insertar , obtener ,imprimir 

STREAM_DELAY = 1  # second
RETRY_TIMEOUT = 15000  # milisecond

import redis

r = redis.Redis(host="localhost", port="6379")
r.mset({"nombre":"joaquin"})
r.mset({"paso":"false"})
dat = r.get('nombre').decode("utf-8") # Decodificamos con decode("utf-8")
print('REDIS :-->',dat)
mq = r.pubsub()
mq.subscribe('reunion')

#-----------------------------------------------------------------
# ARRANCANDO LA APLICACION 

@app.on_event("startup")
def on_startup():
    print('ARRANCADO APLICACION')

#--------------------------------------------------------------
# al PARAR la aplicacion
@app.on_event('shutdown')
async def shutdown_event():
    print('PARAR DE LA APLICACION')

#-----------------------------------------------------------------
# CERTIFICADOS
#-----------------------------------------------------------------
DER_BASE64_ENCODED_PRIVATE_KEY_FILE_PATH = os.path.join(os.getcwd(),"private_key.txt")
DER_BASE64_ENCODED_PUBLIC_KEY_FILE_PATH = os.path.join(os.getcwd(),"public_key.txt")

VAPID_PRIVATE_KEY = open(DER_BASE64_ENCODED_PRIVATE_KEY_FILE_PATH, "r+").readline().strip("\n")
VAPID_PUBLIC_KEY = open(DER_BASE64_ENCODED_PUBLIC_KEY_FILE_PATH, "r+").read().strip("\n")

VAPID_CLAIMS = {
"sub": "mailto:informatico.joaquin@gmail.com"
}



#------------------------------------------------------------------
# PWA
#------------------------------------------------------------------

#----------------------------------------------------------
# ENVIAR MENSAJES
#-------------------------------
def send_web_push(subscription_information, message_body):

    res = json.loads(subscription_information)
   
    return webpush(
        subscription_info=res,
        data=message_body,
        vapid_private_key=VAPID_PRIVATE_KEY,
        vapid_claims=VAPID_CLAIMS
    )
#--------------------------------
# OBTENER SUBCRIPCION

@app.get("/envio")
def envio():
    r.mset({"nombre":"actualizar"})
    r.mset({"paso":"true"})
    return 'ok'

@app.get("/subcripcion/")
def subscription():
    print('PUBLICK KEY ',VAPID_PUBLIC_KEY)
    response = JSONResponse({'public_key':VAPID_PUBLIC_KEY})
    return response
#-------------------------------------------------------------------
# GUARDAR SUBCRIPCION

class Token2(BaseModel):
    sw_token:str
    cliente_id:int

#----------------------------------------------------------------------
# SUBCRIPCION POST GRABAR EN BASE DE DATOS USUARIO

@app.post("/subcripcion/")
def subscription(sw_token:Token2 , db: Session = Depends(get_session)):
    
    token = db.query(Token).filter(Token.sw_token == sw_token.sw_token).first()
    if token:
        send_web_push(token.sw_token,'YA SUSCRITO')
        print('YA ESTÁ SUSCRITO')
        response = JSONResponse({'resultado':'ok'})
        return response
    else:
        db_token = Token()
        db_token.sw_token = sw_token.sw_token
        db.add(db_token)
        db.commit()
        send_web_push(db_token.sw_token,'SUSCRITO A LA APLICACION')
        response = JSONResponse({'resultado':'ok'})
        return response


#-----------------------------------------------------------------------------
# MENSAJE
#-----------------------------------
def delay_mensaje():
    print('ENTRO EN  EL THREAD ')
    r.mset({"paso":"false"})
    time.sleep(1)
    r.mset({"nombre":""})
    print('PASO POR EL THREAD ')
    
#-----------------------------------------------------------
# en linea con el cliente
#-----------------------------------------------------------
@app.get('/stream')
async def message_stream(request: Request):
    def new_messages():
        # Add logic here to check for new messages
        # AQUI MENSAJES A ENVIAR
        # TRUE VERDAD Y None no enviar 
        # yield None
        
        dat = r.get('nombre').decode("utf-8")
        paso = r.get('paso').decode("utf-8")
        print('PASO-->',paso)
        if dat == 'actualizar':
            if paso == 'true' :
                print('PASO EL PASO')
                r.mset({"paso":"false"})
                retraso_mensaje = threading.Thread(target=delay_mensaje)
                retraso_mensaje.start()
            return True
        else: 
            return None
    
    async def event_generator():
        while True:
            # If client closes connection, stop sending events
            if await request.is_disconnected():
                break
            print('MENSAJES:------->',new_messages())
           
            dat = r.get('nombre').decode("utf-8")
      
            print('REDIS:------->',dat)
     

            # Checks for new messages and return them to client if any
            if new_messages():
                print('entro en el mensaje')
                yield {
                        "event": "actualizar",
                        "id": "message_id",
                        "retry": RETRY_TIMEOUT,
                        "data": "message_content"
                }

            await asyncio.sleep(STREAM_DELAY)
    print('stream')

    return EventSourceResponse(event_generator())
#------------------------------------------------------------------


#------------------------------------------------------------
# WEBSOCKET 

class ConnectionManager:

    def __init__(self):
        self.active_connections: List[WebSocket] = []

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.append(websocket)
        await websocket.send_text('CONECTADO')
        print('CONECTADO :-->',self.active_connections)


    def disconnect(self, websocket: WebSocket):
        self.active_connections.remove(websocket)
        print('desCONECTADO :-->',self.active_connections)

    async def send_personal_message(self, message: str, websocket: WebSocket):
        await websocket.send_text(message)
        print('mensaje:-->',message)

    async def broadcast(self, message: str):
        for connection in self.active_connections:
            await connection.send_text(message)


manager = ConnectionManager()

#------------------------------------------------------------------------------
@app.websocket("/wss/{client_id}")
async def websocket_endpoint(websocket: WebSocket, client_id: int):
  
    await manager.connect(websocket)

    
    try:
        while True:
            data = await websocket.receive_text()
            await manager.send_personal_message(f"You wrote: {data}", websocket)
            await manager.broadcast(f"Client #{client_id} says: {data}")
     
    except WebSocketDisconnect:
        manager.disconnect(websocket)
        await manager.broadcast(f"Client #{client_id} left the chat")
#-------------------------------------------------------------------------------------
#---------------------------------------------------------------
# SE EJECUTA ANTES DE CADA PETICION AL SERVIDOR.
# Luego pasa al servidor .. a la peticion solicitada

@app.middleware("http")
async def verificar_usuario(request: Request, call_next):
    #obtenemos la session que se le dio al cliente
    print('ANTES DE CADA PETICION A LA API')
    print('***********************',request.cookies)
    # decodificamos la session
    #session = decode(request.cookies['session'] ,key="adriana03",algorithms=["HS256"] )
    # y tenemos nombre y el id del usuario y cuando expira.
    #print('SESSION :-->',session)
    # podemos mirando cuando expira.

    # y si queremos lo mandamos a login..
    #return plantilla.TemplateResponse("/0_login/login.html", {"request": request})
    response = await call_next(request)
    return response 

#------------------------------------------------------------------------
def loguear():
    print('estoy en loguearse ')
    return 'hola'

@app.get("/",response_class=HTMLResponse)
async def root(request: Request, pasar: str = Depends(loguear) ,db: Session = Depends(get_session)):
    print('PASAR POR LA RAIZ :-->',pasar)
    r.mset({"mensaje":pasar})
    if 'session' in request.cookies :
        session = decode(request.cookies['session'] ,key="adriana03",algorithms=["HS256"] )
        usuario = db.query(Usuario).get(session['id'])

        if usuario :

            if 'Android' in request.headers['user-agent']:
                print('estas usando un movil')
                print('request:---->',request.headers['user-agent'])
                #print('PLATAFORMA:--------------------________>',request.headers['sec-ch-ua-platform'])
                return plantilla.TemplateResponse("/02_movil/movil2.html", {"request": request , 'session':session})

            if 'iPhone' in request.headers['user-agent']:
                print('estas usando un movil')
                print('request:---->',request.headers['user-agent'])
                #print('PLATAFORMA:--------------------________>',request.headers['sec-ch-ua-platform'])
                return plantilla.TemplateResponse("/02_movil/movil2.html", {"request": request , 'session':session})

            if 'ADMINISTRADOR' in usuario.perfil :
                return plantilla.TemplateResponse("/admin/admin.html", {"request": request , 'session':session})
            #/01_admin/admin.html
        else:
            return plantilla.TemplateResponse("/0_login/login.html", {"request": request})    

    else:
        return plantilla.TemplateResponse("/login/login.html", {"request": request})
 
    return plantilla.TemplateResponse("/login/login.html", {"request": request})

@app.get("/p",response_class=HTMLResponse)
async def root2(request: Request,db: Session = Depends(get_session)):

    print('request: -->',request.cookies)

    return plantilla.TemplateResponse("/index.html", {"request": request})
#----------------------------------------------------------------
# LOGUEARSE 

@app.post("/loguearse", tags=["login"])
def loguearse(usuario:Usuario, db: Session = Depends(get_session)):
    """
          ESTO ES DOCUMENTACION ADICIONAL
    """

    # mensaje = decode(token ,key="adriana03",algorithms=["HS256"] )

    db_usuario = db.query(Usuario).filter(Usuario.usuario == usuario.usuario,Usuario.clave == usuario.clave).first()
    token = ''
    
    if db_usuario :
        token = encode(payload={'nombre':db_usuario.usuario,'id':db_usuario.id,'expira':'2/03/2023'},key="adriana03",algorithm="HS256")
        resultado = 'ok'
        response = JSONResponse({'resultado':resultado})
        response.set_cookie(key="session", value=token)
        response.set_cookie(key="id", value=db_usuario.id)
        response.set_cookie(key="usuario", value=db_usuario.usuario)

    else:
        resultado = 'no valido'
        response = JSONResponse({'resultado':resultado})

    return response

#-------------------------------------------------------------------
# LOGOUT 

@app.get("/logout")

def logout():

    response = JSONResponse({'resultado':'ok'})
    response.delete_cookie("session")

    return response


#-------------------------------------------------------------------
@app.post("/usuario")
async def usuario(usuario:Usuario,db: Session = Depends(get_session)):
    print('USUARIO:->',usuario)

    url = f"mariadb+mariadbconnector://joaquin:adriana03@localhost/saw"
    sql_usuario = 'select * from usuario'
    df_usuario = pd.read_sql(sql_usuario, con = url)
    for i,fila in df_usuario.iterrows():
        print('id:',fila['id'])
        print('usuario:',fila['usuario'])
        print('clave:',fila['clave'])

    #usuarios = db.query(Usuario).all()
    return df_usuario.to_dict('records')

class Usuariosalida(Usuario):
    def notas2(self):
        return self.notas
   

@app.post("/listar_usuarios", response_model=List[UsuarioSal])
async def listar_usuarios(db: Session = Depends(get_session)):
    
    comandos = select(Usuario).outerjoin(Nota).group_by(Usuario.id)
    #comandos = 'select usuario from usuario'
    #re1 = db.query(Usuario).options(lazyload(Usuario.notas)).all()
    usuarios = db.exec(comandos).all()[::-1]
 
    re2 = db.query(Usuario).all()[::-1]
   
    #
    return usuarios

@app.post("/añadir_usuario")
async def añadir_usuario(usuario:Usuario,db: Session = Depends(get_session)):
    usuario.id = None
    db.add(usuario)
    db.commit()
    db.refresh(usuario)
    return usuario

@app.post("/editar_usuario")
async def editar_usuario(usuario:Usuario,db: Session = Depends(get_session)):

    db_usuario = db.get(Usuario,usuario.id)
    data_usuario = usuario.dict(exclude_unset=True)
    for key, value in data_usuario.items():
        setattr(db_usuario, key, value)
    
    db.commit()
    db.refresh(db_usuario)
    return db_usuario

@app.post("/eliminar_usuario")
async def eliminar_usuario(usuario:Usuario,db: Session = Depends(get_session)):

    db_usuario = db.get(Usuario,usuario.id)
    
    db.delete(db_usuario)
    db.commit()

    return 'ok'

@app.post("/añadir_nota_usuario")
async def añadir_nota_usuario(id:int,nota:Nota,db: Session = Depends(get_session)):

    db_usuario = db.get(Usuario,id)
    db_usuario.notas.append(nota)
    db.commit()
    db.refresh(db_usuario)
    return db_usuario

@app.get("/enviar")
async def enviar():

    send_web_push('{"endpoint":"https://fcm.googleapis.com/fcm/send/d3pu_7YkH5w:APA91bHBjMhPalUf-pmYFBwkgZLWNtqKdnY535r11-mvoOqdO0Obct8nMK0j0x1-iR27dZ1Sm7dO-PaUKKSEoiMgrydz9il75ipr0GLsYHJlNzAqC6yDzG4BE0q3FSs1P5yBB7yubtVc","expirationTime":null,"keys":{"p256dh":"BPZSBatbmBrobPhE73A2Vabjd45N6UTzP3Qofu2wuzszcGJ_tmPu-TF_YOGSZDCaPwz3WvJ8bZAGWLikQ7oqzOY","auth":"hbPMas1WlSiL82VY4D8pkw"}}','HOLA TE ESTOY ENVIANDO UN MENSAJE')
    return 'ok'


@app.get("/comentario",response_class=HTMLResponse)
async def comentario(request: Request,db: Session = Depends(get_session)):
    return plantilla.TemplateResponse("/comentario.html", {"request": request})


@app.get("/nombre/{id}",response_class=HTMLResponse)
async def nombre(id:int,request: Request, db: Session = Depends(get_session)):
    print('id-->',id)
    return plantilla.TemplateResponse("/nombre.html", {"request": request})


@app.post("/nombre2",response_class=HTMLResponse)
async def nombre2(nombre: Annotated[str, Form()],apellidos: Annotated[str, Form()],request: Request, db: Session = Depends(get_session)):

    print('nombre:',type(nombre))

    lin = json.loads(nombre)
    print('edad:->',lin)
   
   

    print('apellidos:',apellidos)


    return plantilla.TemplateResponse("/nombre2.html", {"request": request})

@app.post('/datos')
async def datos(db: Session = Depends(get_session)):

    re = [
        1,2,3
    ]


    return re

@app.post('/cambia',response_class=HTMLResponse)
async def cambia(request: Request,db: Session = Depends(get_session)):


    return plantilla.TemplateResponse("/cambia.html", {"request": request})



@app.post('/webhook')
async def webhook(request : Request):
    message = await request.json()
   
    if 'message' in message :
        chat_id = message["message"]["from"]["id"]
        mensaje = message["message"]["text"]
        print('chat_id:->',chat_id)
        print('MENSAJE:->',mensaje)

        url = "https://api.telegram.org/bot6641035830:AAFt6itx1-6n5Q3-MD7v4kWgtiMismbk94Y/sendMessage"
        async with httpx.AsyncClient() as client:
            nombre = message["message"]["from"]["first_name"]
            salida = f'Hola {nombre}, soy el servidor que deseas ..'
            response = await client.post(url=url , json={"chat_id":chat_id,"text":salida})

        url = "https://api.telegram.org/bot6641035830:AAFt6itx1-6n5Q3-MD7v4kWgtiMismbk94Y/sendPhoto"
        async with httpx.AsyncClient() as client2:
            url_foto = 'https://saw.freemyip.com/file/salir.png'
            response2 = await client2.post(url=url , json={"chat_id":chat_id,"photo":url_foto})

    print('MENSAJE:-->',message)




    return message

# Descargar fichero con fastapi
@app.get("/file/{name_file}")
def get_file(name_file: str):
    return FileResponse(path=getcwd() + "/" + name_file)

# Nuevo Cliente
@app.post("/admin/nuevo_cliente")
async def nuevo_cliente(cliente:Cliente,db: Session = Depends(get_session)):
  
    db.add(cliente)
    db.commit()
    db.refresh(cliente)
    return cliente


class Dato(BaseModel):

    busqueda:Optional[str] = ''
    page:Optional[int]=1 
    size:Optional[int]=50


class Cli(BaseModel):

    id:Optional[int] = 1
    nombre:Optional[str]=''
    nif_cif:Optional[str]=''
    email:Optional[str]=''
    web:Optional[str]=''
    tf1:Optional[str]=''
    tf2:Optional[str]=''
    fax:Optional[str]=''

    contactos:List[Contacto] = []
    direcciones:List[Direccion]=[]


# Listar Clientes
@app.post("/admin/listar_clientes", response_model=Page[Cli])
async def listar_clientes(dato: Dato, db: Session = Depends(get_session)):

    #Paginacion page = 1 , size = 20  ejemplo.
    # https://tresbaez.freemyip.com/admin/listar_clientes?page=2&size=20 
    # query --> ?page=1&size=10 

    buscado = dato.busqueda.replace(' ','%')
    buscar = f'%{buscado}%'

    print('------------------------db--->',dir(db.query(Cliente)))

    clientes = db.query(Cliente).outerjoin(Contacto).outerjoin(Direccion).filter(or_(Cliente.nombre.like(buscar),
        Cliente.nif_cif.like(buscar),
        Contacto.movil.like(buscar),
        Cliente.web.like(buscar),
        Cliente.email.like(buscar))).all()

    print('------------------------clientes------',clientes)




    #comandos = select(Usuario),all()
    #comandos = 'select usuario from usuario'
    #re1 = db.query(Usuario).options(lazyload(Usuario.notas)).all()
    #clientes = db.exec(comandos).all()[::-1]
 
    #re2 = db.query(Cliente).all()
   
    #
    per = paginate(clientes)
   
    return per

# EDITAR cliente
@app.post('/admin/editar_cliente')
async def editar_cliente(cliente:Cliente , db: Session = Depends(get_session)):

    print('EDITAR CLIENTE :----->',cliente)


    #Obtenemos registro unico de la base de datos
    cliente_db = db.query(Cliente).get(cliente.id)
    print('EDITAR CLIENTE :----->',cliente_db)

    #Pasamos a diccionario
    cliente_dict = cliente.dict(exclude_unset=True)

    print('EDITAR CLIENTE  dict.   :----->',cliente_dict)

    
    # Recorremos cada campo del diccionario
    # y se lo asignamos al registro
    for key , val in cliente_dict.items():
        setattr(cliente_db,key,val)

    db.commit()
    db.refresh(cliente_db)

    return 'ok'

# Eliminar Cliente
@app.post('/admin/eliminar_cliente')
async def eliminar_cliente(cliente:Cliente , db: Session = Depends(get_session)):

    print('CLIENTE ELIMINADO:-->',cliente)

    cliente1 = db.query(Cliente).get(cliente.id)
   
    db.delete(cliente1)
    db.commit()
    
 
    return 'ok'

# Nuevo Contacto
@app.post("/admin/nuevo_contacto")
async def nuevo_contacto(contacto:Contacto,db: Session = Depends(get_session)):
  
    db.add(contacto)
    db.commit()
    db.refresh(contacto)
    return contacto

# Editar Contacto
@app.post('/admin/editar_contacto')
async def editar_contacto(contacto:Contacto , db: Session = Depends(get_session)):

    print('EDITAR CONTACTO :----->',contacto)


    #Obtenemos registro unico de la base de datos
    contacto_db = db.query(Contacto).get(contacto.id)
    print('EDITAR CONTACTO :----->',contacto_db)

    #Pasamos a diccionario
    contacto_dict = contacto.dict(exclude_unset=True)

    print('EDITAR CONTACTO  dict.   :----->',contacto_dict)

    
    # Recorremos cada campo del diccionario
    # y se lo asignamos al registro
    for key , val in contacto_dict.items():
        setattr(contacto_db,key,val)

    db.commit()
    db.refresh(contacto_db)

    return 'ok'

# Eliminar Contacto
@app.post('/admin/eliminar_contacto')
async def eliminar_contacto(contacto:Contacto , db: Session = Depends(get_session)):

    print('CLIENTE ELIMINADO:-->',contacto)

    contacto1 = db.query(Contacto).get(contacto.id)
   
    db.delete(contacto1)
    db.commit()
    
 
    return 'ok'

# Nueva Direccion
@app.post("/admin/nueva_direccion")
async def nueva_direccion(direccion:Direccion,db: Session = Depends(get_session)):
  
    db.add(direccion)
    db.commit()
    db.refresh(direccion)
    return direccion

# Editar Direccion
@app.post('/admin/editar_direccion')
async def editar_direccion(direccion:Direccion , db: Session = Depends(get_session)):

    print('EDITAR CONTACTO :----->',direccion)


    #Obtenemos registro unico de la base de datos
    direccion_db = db.query(Direccion).get(direccion.id)
    print('EDITAR CONTACTO :----->',direccion_db)

    #Pasamos a diccionario
    direccion_dict = direccion.dict(exclude_unset=True)

    print('EDITAR CONTACTO  dict.   :----->',direccion_dict)

    
    # Recorremos cada campo del diccionario
    # y se lo asignamos al registro
    for key , val in direccion_dict.items():
        setattr(direccion_db,key,val)

    db.commit()
    db.refresh(direccion_db)

    return 'ok'

# Eliminar Direccion
@app.post('/admin/eliminar_direccion')
async def eliminar_direccion(direccion:Direccion , db: Session = Depends(get_session)):

    print('CLIENTE ELIMINADO:-->',direccion)

    direccion1 = db.query(Direccion).get(direccion.id)
   
    db.delete(direccion1)
    db.commit()
    
 
    return 'ok'
#---------------------------------------------------------
# PAGINADOR 
#---------------------------------------------------------
add_pagination(app)
#---------------------------------------------------------