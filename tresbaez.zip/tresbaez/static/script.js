//-------------------------------------------------------------------
// SCRIPT.JS
// 


let swRegistration = null;

// funcion decodificadora
function urlB64ToUint8Array(base64String) {
	const padding = '='.repeat((4 - base64String.length % 4) % 4);
	const base64 = (base64String + padding)
		.replace(/\-/g, '+')
		.replace(/_/g, '/');

	const rawData = window.atob(base64);
	const outputArray = new Uint8Array(rawData.length);

	for (let i = 0; i < rawData.length; ++i) {
		outputArray[i] = rawData.charCodeAt(i);
	}
	return outputArray;
}
// pide permiso para enviar notificaciones
if (true){

if ('serviceWorker' in navigator && 'PushManager' in window) {
    navigator.serviceWorker.register('static/sw.js?v=89')
      .then(reg => {
   
        swRegistration = reg
        localStorage.setItem('reg',reg);
        console.log('Registro de SW exitoso', reg)
        Notification.requestPermission(function(result) {
          if (result === 'denied') {
            console.log('Permission wasn\'t granted. Allow a retry.');
            return;
          } else if (result === 'default') {
            console.log('The permission request was dismissed.');
            return;
          }
          // Hacer algo con el permiso concedido.
          if (result === "granted") {
            navigator.serviceWorker.ready.then((registration) => {
              registration.showNotification("Vibration Sample", {
                body: "Buzz! Buzz!",
                icon: "../images/touch/chrome-touch-icon-192x192.png",
                vibrate: [200, 100, 200, 100, 200, 100, 200],
                tag: "vibration-sample",
              });
            });
          }
        });
      })
      .catch(err => console.warn('Error al tratar de registrar el sw', err))
  }

}

// REGISTRARSE EN LA APLICACION

// SOLICITO CERTIFICADO A LA APLICACION
function clave_servidor(){
    swRegistration = localStorage.getItem('reg');
    axios.get('/subcripcion/')
    .then(function (response) {
   
      console.log(' clave del servidor:--->',response);
      localStorage.setItem('applicationServerPublicKey',response.data.public_key)
      const applicationServerPublicKey = localStorage.getItem('applicationServerPublicKey');
      const applicationServerKey = urlB64ToUint8Array(applicationServerPublicKey);
      console.log('swRegistration:--->',swRegistration)
      console.log('applicationServerPublicKey:--->',applicationServerKey)
      swRegistration.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: applicationServerKey
      })
      .then(function(subscription) {
        console.log('usuario suscrito ');
        console.log('usuario token : ',JSON.stringify(subscription));
        localStorage.setItem('sw_token',JSON.stringify(subscription));
        enviar();


      })
      .catch(function(err) {
        console.log('error al subscribirse', err);
    
      });

    })

  }

  // COMPRUEBA QUE SI EN LA SESION DEL CLIENTE TIENE EL TOKEN 
  // SINO LO VUELVE A PEDIR .
  if (!localStorage.getItem('sw_token')){
    console.log('sw_token',localStorage.getItem('sw_token'))
    console.log('no hay token:----> ',localStorage.getItem('sw_token'))
       clave_servidor()
  }
  
  // ENVIAR TOKEN PARA SU REGISTRO
  // EN LA BASE DE DATOS.
  async function enviar(){
    const json = JSON.stringify({'sw_token':localStorage.getItem('sw_token')});
    var datos = {"sw_token":localStorage.getItem('sw_token'),
                "cliente_id":34  }
    const res = await axios.post('/subcripcion/', datos ).then( response =>{
      console.log('respuesta:',response)
    }

    );
  }

  