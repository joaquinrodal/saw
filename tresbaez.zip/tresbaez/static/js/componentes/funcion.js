//---------------------------------------
// INTRODUCIR CAMINO
function introducir_camino(valor){
    this.camino.push(valor)
 }
 //------------------------------------
 // ATRAS CAMINO 
function atras_camino(){

    if(this.camino.length > 1){
        this.camino.pop()
        this.tab = this.camino.at(-1)
    }else{
        this.camino.pop()
        this.tab='menu'
    }
}
//--------------------------------------

function salir(){
    axios.get('/logout')
    .then(resp =>{
        window.location.href = '/'
    })
 
  }
  //---------------------------------
function nuevo_cliente(){

    var data = {...this.cliente}
    axios.post('/admin/nuevo_cliente',data)
    .then(resp =>{
        this.listar_clientes()
        //this.api('/admin/listar_clientes','','clientes','clientes')
       
    } )
}
//-------------------------------------
async function editar_cliente(){

    var data = {...this.cliente}
    delete data.contactos
    delete data.direcciones
    console.log('EDITAR CLIENTE',data)
    axios.post('/admin/editar_cliente',data)
    .then(resp =>{
        this.listar_clientes()
        this.tab = 'clientes'
        //this.api('/admin/listar_clientes','','clientes','clientes')
        
    } )
}
//---------------------------------------
function eliminar_cliente(){

    var data = {...this.cliente}
    delete data.contactos
    delete data.direcciones
    console.log('CLIENTE A ELIMINAR :-->', data)
    axios.post('/admin/eliminar_cliente',data)
    .then(resp =>{
        
        this.listar_clientes()
        //this.api('/admin/listar_clientes','','clientes','clientes')
        
    } )
}
//-----------------------------------------
function listar_clientes(){
    const  alpine = document.body._x_dataStack[0]

    var dat = {'busqueda': alpine.cbusqueda}
    var url_consulta = `/admin/listar_clientes?page=${alpine.pagina}&size=${20}`
    console.log('DATA LISTAR CLIENTES :',dat,url_consulta)
    axios.post(url_consulta,dat)
    .then(resp =>{
        //Actualizamos listado de clientes
        alpine.clientes = resp.data.items
        alpine.pagina = resp.data.page
        alpine.paginas = resp.data.pages
        alpine.total = resp.data.total
        //Actualizamos el registro cliente
        alpine.cliente = alpine.clientes[alpine.cliente_index]
    

    })
}

  //---------------------------------
  function nuevo_contacto(){
    const  alpine = document.body._x_dataStack[0]
    var data = {...this.contacto}
    console.log('cliente id----',alpine.cliente.id )
    data['cliente_id'] = alpine.cliente.id 
    console.log('CONTACTO :-->',data)
    axios.post('/admin/nuevo_contacto',data)
    .then(resp =>{
        this.listar_clientes()
        
        //this.api('/admin/listar_clientes','','clientes','clientes')
       
    } )
}
//-------------------------------------
async function editar_contacto(){

    var data = {...this.contacto}

    console.log('EDITAR CONTACTO',data)
    axios.post('/admin/editar_contacto',data)
    .then(resp =>{
        this.listar_clientes()
      
        //this.api('/admin/listar_clientes','','clientes','clientes')
        
    } )
}
//---------------------------------------
function eliminar_contacto(){

    var data = {...this.contacto}
    console.log('CONTACTO A ELIMINAR :-->', data)
    axios.post('/admin/eliminar_contacto',data)
    .then(resp =>{
        
        this.listar_clientes()
        //this.api('/admin/listar_clientes','','clientes','clientes')
        
    } )
}
  //---------------------------------
  function nueva_direccion(){
    const  alpine = document.body._x_dataStack[0]
    var data = {...this.direccion}
    console.log('cliente id----',alpine.cliente.id )
    data['cliente_id'] = alpine.cliente.id 
    console.log('CONTACTO :-->',data)
    axios.post('/admin/nueva_direccion',data)
    .then(resp =>{
        this.listar_clientes()
        
      
        //this.api('/admin/listar_clientes','','clientes','clientes')
       
    } )
}
//-------------------------------------
async function editar_direccion(){

    var data = {...this.direccion}

    console.log('EDITAR DIRECCION',data)
    axios.post('/admin/editar_direccion',data)
    .then(resp =>{
        this.listar_clientes()
       
        //this.api('/admin/listar_clientes','','clientes','clientes')
        
    } )
}
//---------------------------------------
function eliminar_direccion(){

    var data = {...this.direccion}
    console.log('CONTACTO A ELIMINAR :-->', data)
    axios.post('/admin/eliminar_direccion',data)
    .then(resp =>{
        
        this.listar_clientes()
        //this.api('/admin/listar_clientes','','clientes','clientes')
        
    } )
}
//------------------------------------------
function sumar(a,b){return a+b}

function api(url,data,destino,tab,fn){
    console.log('API  :',url,data,destino)
    const  alpine = document.body._x_dataStack[0]
    axios.post(url,data)
    .then(resp=>{
        if(fn){
            alpine[fn]()
        }
        console.log('API RESULTADO :',resp.data)
        if(destino){
            alpine[destino] = resp.data
        }
        if(tab){
            this.tab = tab
        }
        
    })
}
function mostrar(){
    console.log('HOLA JAVASCRIT')
}
export {sumar,
        api,
        salir,
        mostrar,
        introducir_camino,
        atras_camino,
        listar_clientes,
        nuevo_cliente,
        nuevo_contacto,
        editar_cliente,
        eliminar_cliente,
        editar_contacto,
        eliminar_contacto,
        nueva_direccion,
        editar_direccion,
        eliminar_direccion}
        
console.log('FUNCTION CARGADA')