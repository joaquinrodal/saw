// Forma de cargar los ficheros 
// forzados a que carguen cada vez que actualizen.

var numero = Math.floor(Math.random() * 21234);

var ruta1 = `./funcion.js?v=${numero}`
var ruta2 = `./e-busqueda.js?v=${numero}`
var ruta3 = `./e-caja.js?v=${numero}`

import (ruta1)
import (ruta2)
import (ruta3)


