
import {LitElement, html,css} from '/static/js/lit/lit-element.js';


export  class ECaja extends LitElement {
    
    static get properties(){
        return{
           
        }
    }
    constructor(){
        super()
        this.alpine=document.body._x_dataStack[0]
    }
    
    createRenderRoot() {return this;}

    render() {
      return html /* html */ `
      
      <div class="border rounded-[8px] 
                                w-[40px] h-[40px]
                                absolute top-[3px] left-[55px] 
                                flex justify-center items-center cursor-pointer 
                                hover:bg-[#EEEDED]">
                             A
                    </div>
 
      `;
    }

  }
  customElements.define('e-caja', ECaja);