
import {LitElement, html,css} from '/static/js/lit/lit-element.js';
import {sumar} from '/static/js/componentes/funcion.js';

export  class EBusqueda extends LitElement {
    
    static get properties(){
        return{
            valor:{type:String}
        }
    }
    constructor(){
        super()
        this.alpine=document.body._x_dataStack[0]
    }
    
    createRenderRoot() {return this;}

    actualizar(){
      this.alpine['valor'] = 'hola componente actualizado';
      this.requestUpdate();
      console.log('SUMAR A + B = ', sumar(3,4) )
    }

    render() {
      return html /* html */ `
      ...
       <span>${this.alpine['valor']}</span>***
       <div class="bg-[#F26C57] text-[20px] px-[30px]" 
            x-text="'${this.valor}'"> </div>
       <div @click=${this.actualizar} class="cursor-pointer font-bold"
             >ACEPTAR</div>

 
      `;
    }

  }
  customElements.define('e-busqueda', EBusqueda);