//---------------------------------------------------------------
// LOGICA ALPINE 3 

function data_login(){
    return {
     
        usuario : {},
        ver:false,
        info:false,
        enviar : function(){

          
            var user = {usuario : this.usuario.usuario, 
                        clave: this.usuario.clave}
            console.log('USUARIO:-->',user)
            if (typeof (this.usuario.clave) === 'undefined' || typeof (this.usuario.usuario) === 'undefined') {
                this.info = true
                setTimeout( ()=>{
                    this.info = false
                },1500)
            
             }else{
                let resultado = axios.post('loguearse',user)
                .then(resp =>{
                    console.log('respuesta:',resp.data)
                    if(resp.data.resultado == 'ok'){
                        console.log('usuario valido')
                        window.location.href ='/'
                    }
                    if(resp.data.resultado =='no valido'){
                        console.log('usuario no valido')
                        this.usuario = {
                            'usuario':'',
                            'clave':''
                        }
                        // Dejar de ver aviso pasado 1.5 segundos
                        this.ver = true
                        setTimeout( ()=>{
                            this.ver = false
                        },1500)
                    }
                })
                 
             }

         

        }
    }
}
