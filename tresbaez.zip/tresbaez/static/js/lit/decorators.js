export * from "/static/js/lit/decorador/custom-element.js";
export * from "/static/js/lit/decorador/property.js";
export * from "/static/js/lit/decorador/state.js";
export * from "/static/js/lit/decorador/event-options.js";
export * from "./static/js/lit/decorador/query.js";
export * from "/static/js/lit/decorador/query-all.js";
export * from "/static/js/lit/decorador/query-async.js";
export * from "/static/js/lit/decorador/query-assigned-elements.js";
export * from "/static/js/lit/decorador/query-assigned-nodes.js";
//# sourceMappingURL=decorators.js.map
