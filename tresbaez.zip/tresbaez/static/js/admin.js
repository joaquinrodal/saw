
window.flash = message => window.dispatchEvent(new CustomEvent('flash',{detail:message}));


   document.addEventListener('alpine:init', () => {
     Alpine.magic('ahora', () => {
         return (new Date).toLocaleTimeString()
      })
      Alpine.magic('ver', () => {
         var dat = document.body._x_dataStack[0]
         return ''
      })
      Alpine.directive('mayusculas', el => {
         el.textContent = el.textContent.toUpperCase()
      })
      Alpine.store('almacen','DATOS DEL ALMACEN')
   })







// librerias
import {sumar,
        api,
        salir,
        introducir_camino,
        atras_camino, 
        listar_clientes, 
        nuevo_cliente,
        editar_cliente,
        eliminar_cliente,
        nuevo_contacto,
        editar_contacto,
        eliminar_contacto,
        nueva_direccion,
        editar_direccion,
        eliminar_direccion
       } from './componentes/funcion.js'


// Bloque Principal Applicacion web
window.data_admin = function(){
   return {
   //--------------------------
   // Variables 
    menu:'',
    app:null,
    orden:'ver1',
    camino:[],
    cbusqueda:'',
    pagina:1,
    paginas:1,
    total:0,
    tab:'',
    tab_cliente:'albaranes',
    nombre: '',
    cliente_index:0,
    cliente:{},
    clientes:[],
    contacto:{},
    contactos:[],
    direccion:{},
    direcciones:[],
    datos:'datos almacenados',
    expanded: false,
    count:0,
    contador:localStorage.getItem("contador") || 0,
    show:false,
   
    
    
    
   //----------------------------
   // start
   start: function(){
      
       this.$watch('contador', (value, oldValue) => localStorage.setItem("contador", value))
       console.log('contador:-->',this.count)
       this.app = window.document.body._x_dataStack[0]
       this.listar_clientes()
      //this.api('/admin/listar_clientes','','clientes')

    },
  
   //-----------------------------
   // FUNCIONES
    listar:function(){
      this.api('/admin/listar_clientes','','clientes') 
    },
   api:api,
    salir:salir,
    introducir_camino:introducir_camino,
    atras_camino:atras_camino,
    listar_clientes:listar_clientes,
    nuevo_cliente:nuevo_cliente,
    editar_cliente:editar_cliente,
    eliminar_cliente:eliminar_cliente,
    nuevo_contacto:nuevo_contacto,
    editar_contacto:editar_contacto,
    eliminar_contacto:eliminar_contacto,
    nueva_direccion:nueva_direccion,
    editar_direccion:editar_direccion,
    eliminar_direccion:eliminar_direccion,
    flash:flash,
    


   }
}