

self.addEventListener('push', function(event) {
    console.log('[Service Worker] Push Received.');
    console.log(`[Service Worker] Push had this data: "${event.data.text()}"`);

    const title = 'Notificacion Aplicacion Web';
    const options = {
      body: `"${event.data.text()}"`,
      icon: '/static/iconos/logo_128x128.png',
      badge: '/static/iconos/logo_128x128.png',
      image: '/static/imagenes/ajuste.png',
      sound : '/static/sonido.mp3',
      tag: 'vibration-sample',
      vibrate: [125,75,125,275,200,275,125,75,125,275,200,600,200],
      openUrl:'/'
  
    };
    //const notification = new self.Notification(title, {
     // body: `"${event.data.text()}"`,
     // tag: 'simple-push-demo-notification',
     // icon:'/static/iconos/logo_awp_128x128.png',
    //});
    console.log('opciones',options)
    self.registration.showNotification(title, options)
    event.waitUntil(self.registration.showNotification(title, options));
   
    console.log('registration---->',self.registration)
  
    console.log('SELF ---->',self)
    self.registration.active.postMessage(
      "ESTA MENSAJE SE RECIBE DESDE EL WORKER INTERIOR",
    );
  });
  
  self.addEventListener('notificationclick', function(event) {
    console.log('[Service Worker] Notification click Received.');
  
    event.notification.close();
  
    event.waitUntil(
      clients.openWindow('https://saw.freemyip.com')
    );
  });