#-------------------------------------------------------------
# CONEXION A LA BASE DE DATOS MARIA DB
#-------------------------------------------------------------

from sqlmodel import create_engine ,Session


url = f"mariadb+mariadbconnector://joaquin:adriana03@localhost/tresbaez"
engine = create_engine(url, echo=True ,future=True, pool_recycle=1200)


def get_session():
    with Session(engine, autocommit=False, autoflush=False,expire_on_commit=True) as session:
        yield session



#---------------------------------------------------------------