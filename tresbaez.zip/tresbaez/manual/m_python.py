

#ITERADOR

lista = [1,2,3,4,5]
lis = iter(lista)

next(lis)

tenemos una lista 
y la queremos iterar 
