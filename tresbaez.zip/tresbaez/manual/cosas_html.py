

 <p dir="rtl"> esto es un parrafo. </p>  alineacion a la derecha.

 <button accesskey="l">
    a 
 </button>
 este atributo es pulsando ALT + L Y SE EJECUTA .




<input multiple type="email" list="lista" required />
<datalist id="lista">
   <option value="correo@gmail.com"> </option>
   <option value="correo2@gmail.com"> </option>
   <option value="correo2@gmail.com"> </option>
</datalist>


<p data-nombre="joaquin" id="nombre"> </p>
<button onclick="console.log(nombre.dataset.nombre)">
boton
</button>

# para descargar un archivo 

<a download href="factura.pdf"> fichero </a>