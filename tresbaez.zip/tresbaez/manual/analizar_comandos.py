

    addresses: List["UserAddress"] = Relationship(
        sa_relationship=relationship("UserAddress", cascade="all, delete", back_populates="user_address"))


# Update models
class Hero(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    tests: List["Test"] = Relationship(
        sa_relationship_kwargs={
            "cascade": "all, delete",  # Instruct the ORM how to track changes to local objects
        },
    )


class Test(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    hero_id: Optional[int] = Field(
        sa_column=Column(Integer, ForeignKey("hero.id", ondelete="CASCADE"))  # Set the foreign key behavior on the table metadata
    )

from typing import Optional
from sqlmodel import Field, SQLModel,create_engine, Session


class Worker(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    name: str = Field(index=True)


class Transaction(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    worker_id: int = Field(index=True, foreign_key="worker.id")


# Create a worker
with Session(engine) as session:
    worker = Worker(name='Worker 1')
    session.add(worker)
    session.commit()
    session.refresh(worker)

# Create a transaction pointing to this worker
with Session(engine) as session:
    transaction = Transaction(worker_id=worker.id)
    session.add(transaction)
    session.commit()
    session.refresh(transaction)

# Delete the worker
with Session(engine) as session:
    session.delete(worker)
    session.commit()
    
# Print all transactions on database
with Session(engine) as session:
    transactions = session.query(Transaction).all()
    print(transactions)