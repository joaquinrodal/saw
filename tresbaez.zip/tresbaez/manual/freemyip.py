
#------------------------------------------------------------------------------------------------
# saw.freemyip.com
https://freemyip.com/help?domain=saw.freemyip.com&token=66074f3fc066244a9e5c1ee8

curl https://freemyip.com/update?token=66074f3fc066244a9e5c1ee8&domain=saw.freemyip.com 
curl https://freemyip.com/update?token=66074f3fc066244a9e5c1ee8&domain=saw.freemyip.com&txt=null 

#------------------------------------------------------------------------------------------------
