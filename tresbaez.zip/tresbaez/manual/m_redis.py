
sudo apt -y install redis-server
sudo systemctl enable --now redis-server.service
sudo vim /etc/redis/redis.conf
bind 0.0.0.0
sudo systemctl restart redis-server