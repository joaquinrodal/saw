cat /etc/debian_version
cat /etc/issue
cat /etc/os-release