
video explicativo windows 2022
https://www.youtube.com/watch?v=lJnEZzF6M_E
