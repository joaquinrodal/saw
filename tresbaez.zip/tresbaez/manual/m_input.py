
 <input pattern="[0-9]{3}"

  patron = cualquier numero entre el 0 y el 9 y solo 3 digitos.
  