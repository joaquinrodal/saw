


import pandas as pd

    url = f"mariadb+mariadbconnector://joaquin:adriana03@localhost/island"
    sql = 'select * from dia'
    dataframe = pd.read_sql(sql, con = url)

#AÑADIR FILA

df = df.append(pd.Series(['',23,'texto'],
         index=['columna1','columna2','columna3']), ignore_index=True)
#FILTRAR FILAS SEGUN CONDICIONES

df[(df['COLUMNA1'] == 'F')&(df['COLUMNA2'] > 4)]

#ORDENAR COLUMNAS
df.sort_values('COLUMNA1')

#OCULTAR NAN

df.dropna()

#POSICION. 
df.iloc[fila,columna]
df.iloc[1,('COLUMNA1,COLUMNA2')]


#STRING QUE CONTENGA LI OR DE 
 df = df[df.servicio.str.contains('|'.join(['li']),case=True)]

#AGRUPAR 
df3 = df_resultado.groupby('nombre')['nombre'].count()

Agrupamos donde le decimos que columna queremos adrupar 
y queremos mostrar la columna agrupada y al lado la columna con cuantos registros tiene agrupado.

#OTRA FORMA DE CONTAR.
df2 = df_resultado['nombre'].value_counts()

#CUENTAME CUANTOS REGISTROS HAY CON EL GRUPO LIMPIEZA
df3 = df_resultado.groupby('nombre')['nombre'].count()['limpieza']

de todos los grupos agrupados por el nombre 
cuantos hay de limpieza , y da un numero

#ITERAR CON LA FILAS 

for index, row in df.iterrows():
      print(row["c1"], row["c2"])#